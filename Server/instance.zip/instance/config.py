# firebase
type = "service_account"
project_id = "monk-interview"
private_key_id = "5cc1946f0533c2676ec3f95b9e618df7f8cbef3c"
private_key = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjc9KfriICZfWs\n1pSZuywWW/BbV2uk2FLJUOJ8VDmj4z5jPuS0BolcpbnIR4nlFbIeoH6v93iwt2dw\n4zg+dnvw3aNdAvy5Lxbj4la6UKoPFBooGyw81ha1giGXb+pow9GB2j+8/g8jCa5R\niuOzff9LQ6kQwbXEehb0vIUfywicAF2JD/LAXCP2u4KerK3+6DYkFJBrQYVRJwLA\n4CjlHG2l2DINwFDEa9JhPteNhQX02Txm+w1loIVVJ4VXBsotyU54s8FiSAJXYLaJ\nfpLyYpLueeYNBjM/gjXDdqLWC28hyZiGJZC+gPjL4eVI1FpGeEYQwYI7aE0/Ivp0\n+Wn2LnHPAgMBAAECggEAKMhdZTotgiuugNGJglIRTgLilefaE+dlwJVN7XeWai3p\nAxpONhzraRJwqGgxH9ep+bpR4dX9Zxpb1O7cubkWc6LZf/ue0xXMwE9ZFGPMCrcZ\nT6h4ATXptKAjgYWLF1jEjYHHJYC+hh+EPxRIfCCT8lOPe37Zu4w67hWbobMnEsUd\n3TxBG04aHufoX/ZqdbZDU/s9MxatkMT1lxXRUag22hz18YDh7bL/uj8W7lcuCf4W\n4uwao5kS6ZcJYMsZO43VF/QaTsR1tNzF9Zd9A+ktHfoin4U1hGY1VIYoeBCh53dM\npLUp7GGASj/nrTMgTCKoXpdYt+9dxtlBkMNLH2l0AQKBgQDkeslVOakUrVeG1SUh\niQ8wIKTViCrj4QTgxvqmgA7x84POfs+4Gyz/Rcak7O3eiMebpAYxF3jJGIeMWxD+\n0CSZ2KjRXFYcvm1PojBKUwXbfQonhnvqVOWmpV/rgnsx4DVFCFz7ziy4l3Tr5FFY\ncJmDZixkpw6N3YY1RqPZpdO60QKBgQC3I+j1VF0OlQGtgukTiN+lKgjCraxptns1\nE0SQThvg25nGBlD7ICaRRZH6zvXlRk47jE2SamcB1MQ/P8XLQvsdPTS74GQMx0Ci\nO4KYWaEVg9vyOcSR6KywQ7uVyecAwvAw/IC2euvZUfr4r71pDG44YHEuX58LLqco\nuAb5eh1KnwKBgQCsuw8+uSrUkP/c1YMOyVmMHwG+1QTn5pQTgxq3iZTC4kDBeil7\nnD/2dT/qK5zhYjLVvblYn9AW586CE87TdXRWQu/N56rKbESjsZAkgIOrHerxWsCP\ntcMwq1HK8IhGeqSLHfl9/K7eltI0DBZbcDT+m93v8kQUiGcQG+l/f9iEIQKBgBBM\n0Oos9Q9cMccItMf5UbZ4lEkHfiX2iObDbUHOwep0gS4/16tSRDx/zateCkK6zDG+\nnhTfBYYDMuhSO7+ImaMTlIL4SM9eWKFX3JrEt3KbxtK7U4SNCfmyPZrqWnYV45zo\njGgxbpZsFoNV2Ozln1XDN6+h8RzkrRoRrwU7WioPAoGAcIX98T/rlz1OOkEqrrLA\n8/A3v3VAFP1MrATm9sTBFr1jwuKyWeSQFDsU46uR92O7nmutcvPyjLt77ZCaR6mW\nBfxAZIGYlJFe5VmSZd+D4ChdmdU2cXS1MF4WxHcstVYS1hN73oBTyiGfv1UJx0fw\nGspz0UXZ4EDk2cRf3Jz4+lo=\n-----END PRIVATE KEY-----\n"
client_email = "firebase-adminsdk-8p3g0@monk-interview.iam.gserviceaccount.com"
client_id = "103344523364510126363"
auth_uri = "https://accounts.google.com/o/oauth2/auth"
token_uri = "https://oauth2.googleapis.com/token"
auth_provider_x509_cert_url = "https://www.googleapis.com/oauth2/v1/certs"
client_x509_cert_url ="https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-8p3g0%40monk-interview.iam.gserviceaccount.com"
universe_domain = "googleapis.com"
storage_bucket = "monk-interview.appspot.com"

# flask
SECRET_KEY = 'S3CR3T_K3Y'